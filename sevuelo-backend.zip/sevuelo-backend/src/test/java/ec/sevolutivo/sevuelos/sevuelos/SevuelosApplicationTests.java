package ec.sevolutivo.sevuelos.sevuelos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SevuelosApplicationTests {

    @Test
    void contextLoads() {
    }

}
