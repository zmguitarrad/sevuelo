package ec.sevolutivo.sevuelos.sevuelos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SevuelosApplication {

    public static void main(String[] args) {
        SpringApplication.run(SevuelosApplication.class, args);
    }

}
