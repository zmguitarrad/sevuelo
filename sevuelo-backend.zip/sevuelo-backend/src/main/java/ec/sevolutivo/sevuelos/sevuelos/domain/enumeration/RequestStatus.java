package ec.sevolutivo.sevuelos.sevuelos.domain.enumeration;

public enum RequestStatus {
    NEW, RESERVED
}
